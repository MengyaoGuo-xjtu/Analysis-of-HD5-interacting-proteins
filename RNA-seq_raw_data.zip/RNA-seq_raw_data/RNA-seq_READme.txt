This dataset contains:
the raw data for the RNA-seq shown in fig. S5 & Table S2: 'raw_data' 
the code for the RNA-seq shown in fig. S5 & Table S2: 'script'
the results for analysis of the RNA-seq data: 'results & plot'