This dataset contains:
the raw data for the phosphorylated proteomics shown in Fig. 3E & fig. S3: 'raw_data.xlsx' 
the code for the phosphorylated proteomics shown in Fig. 3E & fig. S3: 'analysis.Rmd'
the results for analysis of the phosphorylated proteomics data: 'plot' and 'results'