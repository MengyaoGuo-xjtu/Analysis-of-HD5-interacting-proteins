#merge TPM in ./results/hsb_deseq/
library("dplyr")
all_tpm<-data.frame()
temp<-list.dirs(path=".",full.names = TRUE,recursive = FALSE)
for (i in c(1:2)){
  setwd(temp[1])
  gene_expression<-read.table(file="gene_abund.tab",header=TRUE,sep="\t")
  singal_cell_tpm<-gene_expression[,c(1,9)]
  colnames(singal_cell_tpm)[2]<-paste(temp[1])
  unique_singal_cell_tpm<-distinct(singal_cell_tpm, Gene.ID, .keep_all = TRUE)
  setwd("./results/hsb_deseq")
}
all_tpm<-unique_singal_cell_tpm 
temp<-list.dirs(path=".",full.names = TRUE,recursive = FALSE)
for (i in c(1:length(temp))){
  setwd(temp[i])
  gene_expression<-read.table(file="gene_abund.tab",header=TRUE,sep="\t")
  singal_cell_tpm<-gene_expression[,c(1,9)]
  colnames(singal_cell_tpm)[2]<-paste(temp[i])
  unique_singal_cell_tpm<-distinct(singal_cell_tpm, Gene.ID, .keep_all = TRUE)
  all_tpm<-merge(all_tpm,unique_singal_cell_tpm,by="Gene.ID",all=TRUE)
  setwd("./results/hsb_deseq")
}
write.csv(all_tpm,file="20231120_NCBI_ALL_TPM.csv")



