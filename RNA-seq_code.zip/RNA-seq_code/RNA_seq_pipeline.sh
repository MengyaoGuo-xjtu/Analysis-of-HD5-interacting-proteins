activate python36
PATH=/data/home/yxliu/.conda/envs/python36/bin/:$PATH

####################################################################################################
############################################   MKDIR   #############################################
####################################################################################################

cd RNA_seq_raw_data
mkdir ref
mkdir qualitycheck
mkdir output
mkdir results
mkdir script
mkdir ./qualitycheck/RAW
mkdir ./qualitycheck/CLEAN

####################################################################################################
###################################### DOWNLOAD THE SRR DATA #######################################
####################################################################################################

#prefetch SRR from NCBI - one SRR number for each row 
#prefetch -O ./output --option-file ./sralist.txt
#SRR to fastq
#cd ./output/
#for dir in `ls`; do 
#        if [[ -d $dir ]] 
#        then
#            cd $dir;
#            nohup fasterq-dump -e 24 --split-3 ./$dir.sra
#            cd ../;
#        fi
#done

####################################################################################################
######################################### RNA-SEQ PIPELINE #########################################
####################################################################################################

extract_splice_sites.py ./ref/gencode.v39.chr_patch_hapl_scaff.annotation.gtf > ./ref/genomic_for_hisat2.ss 
extract_exons.py ./ref/gencode.v39.chr_patch_hapl_scaff.annotation.gtf > ./ref/genomic_for_hisat2.exon
hisat2-build -p 15 --ss ./ref/genomic_for_hisat2.ss --exon ./ref/genomic_for_hisat2.exon ./ref/GRCh38.p13.genome.fa ./ref/genome_for_hisat2_index 
cd ./output/
for dir in `ls`; do 
        if [[ -d $dir ]] 
        then
            cd $dir;
            echo $dir | tee -a ./results/hista2_alignsum.txt;
            md5sum -c MD5.txt >> ./qualitycheck/md5sum.txt
            fastqc -t 48 *.gz -o ./qualitycheck/RAW
            mkdir clean_data;
            fastp -i *_1.fq.gz -o clean_data/out_1_$dir.fastq -I *_2.fq.gz -O clean_data/out_2_$dir.fastq -q 5 -f 10  -u 50 -n 15 -l 30 --thread 12
            fastqc -t 48 clean_data/*.fastq -o ./qualitycheck/CLEAN
            echo $dir | tee -a ./results/flagstat.txt;
            mkdir hsbpipe;
            cd hsbpipe;
            hisat2 -p 48 --known-splicesite-infile ./ref/genomic_for_hisat2.ss --dta -x ./ref/genome_for_hisat2_index -1 ./output/$dir/clean_data/*_1* -2 ./output/$dir/clean_data/*_2* -S ./output/$dir/hsbpipe/$dir.sam &>> ./results/hista2_alignsum.txt
            echo "#-----------------------------------" >> ./results/hista2_alignsum.txt
            samtools view -bS ./output/$dir/hsbpipe/$dir.sam > ./output/$dir/hsbpipe/$dir.bam
            samtools sort -@ 48 ./output/$dir/hsbpipe/$dir.bam -o ./output/$dir/hsbpipe/sorted_$dir.bam
            samtools index -@ 48 ./output/$dir/hsbpipe/sorted_$dir.bam ./output/$dir/hsbpipe/sorted_$dir.bam.index
            samtools flagstat -@ 48 ./output/$dir/hsbpipe/sorted_$dir.bam >> ./results/flagstat.txt
            echo "#-----------------------------------" >> ./results/flagstat.txt
            rm ./output/$dir/hsbpipe/$dir.sam
            rm ./output/$dir/hsbpipe/$dir.bam
            #htseq-count -s no -r name -f bam -m union -i gene_id  {qsBam} {refGtf} >{countOut}
            mkdir ./results/hsb_deseq/utres_$dir
            stringtie ./output/$dir/hsbpipe/sorted_$dir.bam -p 48 -G ./ref/gencode.v39.chr_patch_hapl_scaff.annotation.gtf -A ./results/hsb_deseq/utres_$dir/gene_abund.tab -o ./results/hsb_deseq/utres_$dir/utres_$dir.gtf -B -e
            realpath ./results/hsb_deseq/utres_$dir/utres_$dir.gtf >> ./results/outstringtie.txt
            cd ../;
            cd ..
        fi
done
multiqc ./qualitycheck/RAW/ -o ./qualitycheck/RAW/
multiqc ./qualitycheck/CLEAN/ -o ./qualitycheck/CLEAN/
python ./script/prepDE.py -i ./results/hsb_deseq -g ./results/hsbpipe_gene_count_matrix.csv -t ./results/hsbpipe_transcript_count_matrix.csv